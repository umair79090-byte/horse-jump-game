import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Heart, Pause, Play, Volume2, VolumeX, RotateCcw, Trophy, Coins, Zap, ChevronUp, Sparkles } from 'lucide-react';

type Screen = 'start' | 'playing' | 'paused' | 'gameover';
type Coin = { x:number; y:number; taken:boolean; vx:number; vy:number; magnet:boolean; r:number; phase:number };
type Obstacle = { x:number; y:number; w:number; h:number; kind:'fence'|'log'|'rock'; passed:boolean; hit:boolean };
type Particle = { x:number; y:number; vx:number; vy:number; life:number; max:number; color:string; size:number };
type Floater = { x:number; y:number; life:number; text:string };
type Cloud = { x:number; y:number; s:number; speed:number };

async function api(action: string, args: any) {
  const res = await fetch("actions", { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.error) throw new Error(json.error || 'Request failed');
  return json.data;
}

export default function App(){
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [screen, setScreen] = useState<Screen>('start');
  const screenRef = useRef<Screen>('start');
  const [hud, setHud] = useState({ score:0, coins:0, hearts:3 });
  const [best, setBest] = useState(0);
  const [bestId, setBestId] = useState<string|null>(null);
  const [isNewBest, setIsNewBest] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const soundRef = useRef(true);
  const [saving, setSaving] = useState(false);
  const [saveNote, setSaveNote] = useState('');
  const [size, setSize] = useState({ w: 390, h: 640 });

  const audioRef = useRef<AudioContext|null>(null);
  const bgTimer = useRef<number|null>(null);
  const game = useRef({
    horseY:0, vy:0, jumps:0, grounded:true, holding:false, squash:1, stretch:1,
    speed:4.6, distance:0, score:0, coinsCollected:0, hearts:3,
    coins:[] as Coin[], obstacles:[] as Obstacle[], particles:[] as Particle[], floaters:[] as Floater[],
    clouds:[] as Cloud[], trees:[] as {x:number; s:number}[], time:0, spawnT:0, coinSpawnT:0, invuln:0, shake:0, landed:0,
    groundY:0, horseX:78, dead:false,
  });

  const setScreenBoth = (s:Screen)=>{ screenRef.current=s; setScreen(s); };

  // Load best score
  useEffect(()=>{
    let alive=true;
    (async()=>{
      try{
        const data = await api("records.list", { collection: "horse_jump_best" });
        const rec = data?.records?.[0];
        if(alive && rec){ setBest(Number(rec.value?.best||0)); setBestId(rec.id); }
      }catch{ /* API unavailable in preview — keep in-memory best */ }
    })();
    return ()=>{ alive=false; };
  },[]);

  const ensureAudio = ()=>{
    if(!audioRef.current){
      try{ const AC = window.AudioContext || (window as any).webkitAudioContext; audioRef.current = new AC(); }catch{}
    }
    if(audioRef.current?.state==='suspended') audioRef.current.resume();
    return audioRef.current;
  };

  const tone = (freq:number, dur:number, type:OscillatorType, vol:number, slideTo?:number, delay=0)=>{
    if(!soundRef.current) return;
    const ctx = ensureAudio(); if(!ctx) return;
    const t0 = ctx.currentTime + delay;
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.type=type; o.frequency.setValueAtTime(freq,t0);
    if(slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0+dur);
    g.gain.setValueAtTime(0.0001,t0); g.gain.exponentialRampToValueAtTime(vol,t0+0.02); g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
    o.connect(g); g.connect(ctx.destination); o.start(t0); o.stop(t0+dur+0.05);
  };
  const playJump = ()=> tone(320,0.22,'sine',0.14,720);
  const playCoin = ()=>{ tone(880,0.12,'sine',0.18); tone(1320,0.18,'sine',0.16,undefined,0.07); };
  const playHit = ()=>{ tone(180,0.28,'sawtooth',0.16,70); tone(90,0.2,'square',0.08,50); };
  const playGameOver = ()=>{ [523,440,349,262].forEach((f,i)=> tone(f,0.28,'triangle',0.16,undefined,i*0.16)); };
  const playNewBest = ()=>{ [523,659,784,1046].forEach((f,i)=> tone(f,0.18,'sine',0.15,undefined,i*0.09)); };

  const startBg = ()=>{
    if(bgTimer.current) return;
    let idx=0; const notes=[523,659,784,659,587,659,784,880];
    bgTimer.current = window.setInterval(()=>{
      if(!soundRef.current || screenRef.current!=='playing') return;
      tone(notes[idx%notes.length],0.18,'sine',0.035); idx++;
    }, 420);
  };
  const stopBg = ()=>{ if(bgTimer.current){ clearInterval(bgTimer.current); bgTimer.current=null; } };

  const saveBest = async (finalScore:number, finalCoins:number)=>{
    if(finalScore<=best) return;
    setSaving(true); setSaveNote('');
    const value = { best: finalScore, coins: finalCoins, updatedAt: new Date().toISOString() };
    try{
      if(bestId){
        const data = await api("records.replace", { collection: "horse_jump_best", id: bestId, value });
        if(data?.id) setBestId(data.id);
      } else {
        const data = await api("records.create", { collection: "horse_jump_best", value, idempotency_key: `best-${finalScore}-${finalCoins}-${Date.now()}` });
        if(data?.id) setBestId(data.id);
      }
      setBest(finalScore); setIsNewBest(true); playNewBest(); setSaveNote('Best score saved!');
    }catch(e:any){
      setSaveNote('Best score kept for this session — could not save yet.');
    } finally{ setSaving(false); }
  };

  const resetGame = ()=>{
    const g=game.current;
    g.horseY=0; g.vy=0; g.jumps=0; g.grounded=true; g.speed=4.6; g.distance=0; g.score=0; g.coinsCollected=0; g.hearts=3;
    g.coins=[]; g.obstacles=[]; g.particles=[]; g.floaters=[]; g.invuln=0; g.shake=0; g.dead=false; g.spawnT=70; g.coinSpawnT=30;
    setHud({score:0,coins:0,hearts:3}); setIsNewBest(false); setSaveNote('');
  };

  const startGame = ()=>{
    resetGame(); setScreenBoth('playing'); ensureAudio(); startBg();
  };

  const doJump = useCallback(()=>{
    if(screenRef.current!=='playing') return;
    const g=game.current;
    if(g.grounded){ g.vy=-13.2; g.grounded=false; g.jumps=1; g.squash=0.82; g.stretch=1.18; playJump(); spawnDust(g.horseX+18, g.groundY); }
    else if(g.jumps===1){ g.vy=-11.4; g.jumps=2; g.squash=0.88; g.stretch=1.14; playJump(); burst(g.horseX+24, g.groundY+g.horseY-20, '#FFFFFF', 6); }
  },[]);

  function spawnDust(x:number,y:number){ const g=game.current; for(let i=0;i<7;i++) g.particles.push({x:x+Math.random()*20-10,y:y-2,vx:Math.random()*2-3,vy:-Math.random()*2-0.5,life:28,max:28,color:'#D9B98A',size:3+Math.random()*3}); }
  function burst(x:number,y:number,color:string,n:number){ const g=game.current; for(let i=0;i<n;i++){ const a=Math.random()*Math.PI*2; const s=1+Math.random()*3; g.particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-1,life:30,max:30,color,size:2.5+Math.random()*3}); } }

  const endGame = ()=>{
    const g=game.current; if(g.dead) return; g.dead=true; playGameOver(); stopBg();
    setScreenBoth('gameover');
    const finalScore=Math.floor(g.score); const finalCoins=g.coinsCollected;
    if(finalScore>best) { saveBest(finalScore, finalCoins); } 
  };

  // Resize
  useEffect(()=>{
    const update=()=>{ if(wrapRef.current){ const r=wrapRef.current.getBoundingClientRect(); setSize({w:Math.max(280,r.width), h:Math.max(380,r.height)}); } };
    update(); window.addEventListener('resize', update); return ()=>window.removeEventListener('resize', update);
  },[]);

  // Main loop + drawing
  useEffect(()=>{
    const canvas=canvasRef.current; if(!canvas) return;
    const ctx=canvas.getContext('2d'); if(!ctx) return;
    let raf=0; let last=performance.now();
    const g=game.current;
    // init clouds/trees
    if(g.clouds.length===0){ for(let i=0;i<6;i++) g.clouds.push({x:Math.random()*900, y:18+Math.random()*110, s:0.6+Math.random()*0.9, speed:0.3+Math.random()*0.4}); for(let i=0;i<8;i++) g.trees.push({x:i*180+Math.random()*80, s:0.7+Math.random()*0.6}); }

    const drawHorse = (x:number, y:number, t:number, inAir:boolean)=>{
      ctx.save(); ctx.translate(x,y); const sq=g.squash, st=g.stretch; ctx.scale(sq, st);
      const legSwing = inAir ? 0.6 : Math.sin(t*0.55)*0.9;
      // tail
      ctx.fillStyle='#3A2310'; ctx.beginPath(); ctx.moveTo(-32,-8); ctx.quadraticCurveTo(-52,-2,-48,18); ctx.quadraticCurveTo(-36,12,-30,4); ctx.fill();
      // legs
      ctx.strokeStyle='#6B3F1A'; ctx.lineWidth=7; ctx.lineCap='round';
      const legs=[[-18,14,legSwing],[-6,14,-legSwing],[8,14,legSwing],[18,14,-legSwing]];
      legs.forEach(([lx,ly,sw])=>{
        ctx.beginPath(); ctx.moveTo(lx,ly); ctx.lineTo(lx+Math.sin(sw as number)*12, ly+22+ (inAir? -4:0)); ctx.stroke();
        ctx.fillStyle='#2B1A0A'; ctx.beginPath(); ctx.ellipse(lx+Math.sin(sw as number)*12, ly+24+(inAir?-4:0),6,3,0,0,Math.PI*2); ctx.fill();
      });
      // body
      ctx.fillStyle='#8B5A2B'; ctx.beginPath(); ctx.ellipse(0,0,34,20,0,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#A67C4A'; ctx.beginPath(); ctx.ellipse(-2,-4,26,12,0,0,Math.PI*2); ctx.fill();
      // neck + head
      ctx.fillStyle='#8B5A2B'; ctx.beginPath(); ctx.moveTo(18,-12); ctx.quadraticCurveTo(36,-28,44,-18); ctx.lineTo(52,-8); ctx.lineTo(38,4); ctx.lineTo(16,8); ctx.closePath(); ctx.fill();
      ctx.fillStyle='#8B5A2B'; ctx.beginPath(); ctx.ellipse(48,-8,16,11,-0.2,0,Math.PI*2); ctx.fill();
      // muzzle
      ctx.fillStyle='#D9A679'; ctx.beginPath(); ctx.ellipse(60,-4,8,6,0,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#2B1A0A'; ctx.beginPath(); ctx.arc(60,-5,1.8,0,Math.PI*2); ctx.fill();
      // ear
      ctx.fillStyle='#6B3F1A'; ctx.beginPath(); ctx.moveTo(38,-20); ctx.lineTo(42,-34); ctx.lineTo(48,-20); ctx.fill();
      // mane
      ctx.fillStyle='#3A2310'; ctx.beginPath(); ctx.moveTo(14,-18); ctx.quadraticCurveTo(28,-30,40,-26); ctx.quadraticCurveTo(34,-14,28,-8); ctx.quadraticCurveTo(18,-10,14,-18); ctx.fill();
      ctx.beginPath(); ctx.moveTo(40,-26); ctx.quadraticCurveTo(52,-22,48,-12); ctx.quadraticCurveTo(42,-14,40,-26); ctx.fill();
      // eye
      ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(48,-12,5,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#111'; ctx.beginPath(); ctx.arc(49,-12,2.8,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(50,-13,1,0,Math.PI*2); ctx.fill();
      // saddle
      ctx.fillStyle='#FF4757'; ctx.beginPath(); ctx.roundRect(-10,-16,22,16,5); ctx.fill();
      ctx.fillStyle='#FFD93D'; ctx.fillRect(-10,-2,22,3);
      ctx.restore();
    };

    const frame = (now:number)=>{
      const dt=Math.min(32, now-last); last=now; const fpsFactor=dt/16.7;
      const W=size.w, H=size.h;
      const dpr=Math.min(2, window.devicePixelRatio||1);
      if(canvas.width!==W*dpr){ canvas.width=W*dpr; canvas.height=H*dpr; }
      ctx.setTransform(dpr,0,0,dpr,0,0);
      const groundY = H-78; g.groundY=groundY;
      g.time+=fpsFactor;
      const playing = screenRef.current==='playing';
      if(playing){
        g.distance+=g.speed*fpsFactor; g.score+= g.speed*0.12*fpsFactor + 0.08*fpsFactor;
        g.speed=Math.min(9.5, 4.6 + g.distance*0.0022);
        // physics
        const grav = g.holding && g.vy<0 ? 0.52 : 0.82;
        g.vy+=grav*fpsFactor; g.horseY+=g.vy*fpsFactor;
        if(g.horseY>=0){ if(!g.grounded && g.vy>6){ spawnDust(g.horseX+10, groundY); g.landed=6; } g.horseY=0; g.vy=0; g.grounded=true; g.jumps=0; }
        g.squash += (1-g.squash)*0.18; g.stretch += (1-g.stretch)*0.18;
        if(g.invuln>0) g.invuln-=fpsFactor;
        if(g.shake>0) g.shake-=fpsFactor*0.9;
        // spawns
        g.spawnT-=fpsFactor; g.coinSpawnT-=fpsFactor;
        if(g.spawnT<=0){ const kind:Obstacle['kind'] = (['fence','log','rock'] as const)[Math.floor(Math.random()*3)]; const h = kind==='fence'?38: kind==='log'?22:26; const w = kind==='fence'?42: kind==='log'?56:36; g.obstacles.push({x:W+40,y:groundY-h,w,h,kind,passed:false,hit:false}); g.spawnT= 95 + Math.random()*70 - (g.speed*3); }
        if(g.coinSpawnT<=0){
          const pattern=Math.random(); const baseY=groundY-70-Math.random()*110;
          if(pattern<0.45){ for(let i=0;i<5;i++) g.coins.push({x:W+40+i*38, y: baseY - Math.sin(i/4*Math.PI)*36, taken:false, vx:0, vy:0, magnet:false, r:13, phase:Math.random()*6}); }
          else { for(let i=0;i<4;i++) g.coins.push({x:W+40+i*42, y:baseY, taken:false, vx:0, vy:0, magnet:false, r:13, phase:Math.random()*6}); }
          g.coinSpawnT= 120+Math.random()*120;
        }
        // update coins
        const hx=g.horseX+18, hy=groundY+g.horseY-18;
        g.coins.forEach(c=>{
          if(c.taken) return;
          const dx=hx-c.x, dy=hy-c.y, dist=Math.hypot(dx,dy);
          if(dist<110) c.magnet=true;
          if(c.magnet){ c.vx += dx/dist*0.9; c.vy += dy/dist*0.9; c.x+=c.vx; c.y+=c.vy; c.vx*=0.88; c.vy*=0.88; }
          else { c.x-=g.speed*fpsFactor; }
          if(dist<38){ c.taken=true; g.coinsCollected++; g.score+=10; g.floaters.push({x:c.x,y:c.y-10,life:32,text:'+10'}); burst(c.x,c.y,'#FFD93D',10); playCoin(); }
        });
        g.coins=g.coins.filter(c=>!c.taken && c.x>-60);
        // obstacles
        const horseBox={x:g.horseX-22,y:groundY+g.horseY-38,w:56,h:58};
        g.obstacles.forEach(o=>{
          o.x-=g.speed*fpsFactor;
          const overlap = horseBox.x < o.x+o.w-6 && horseBox.x+horseBox.w > o.x+6 && horseBox.y+horseBox.h > o.y+6 && horseBox.y < o.y+o.h;
          if(overlap && g.invuln<=0 && !o.hit){
            o.hit=true; g.hearts--; g.invuln=70; g.shake=12; playHit(); burst(horseBox.x+30, horseBox.y+20, '#FF4757',14);
            setHud({score:Math.floor(g.score),coins:g.coinsCollected,hearts:g.hearts});
            if(g.hearts<=0){ endGame(); }
          }
        });
        g.obstacles=g.obstacles.filter(o=>o.x>-90);
        setHud({score:Math.floor(g.score),coins:g.coinsCollected,hearts:g.hearts});
      } else {
        // idle bob
        if(screenRef.current==='start') g.horseY = Math.sin(g.time*0.12)*2;
      }
      // particles & floaters always
      g.particles.forEach(p=>{ p.x+=p.vx; p.y+=p.vy; p.vy+=0.12; p.life-=fpsFactor; });
      g.particles=g.particles.filter(p=>p.life>0);
      g.floaters.forEach(f=>{ f.y-=1.1*fpsFactor; f.life-=fpsFactor; });
      g.floaters=g.floaters.filter(f=>f.life>0);

      // DRAW
      ctx.save();
      if(g.shake>0) ctx.translate((Math.random()-0.5)*g.shake, (Math.random()-0.5)*g.shake);
      // sky
      const sky=ctx.createLinearGradient(0,0,0,H); sky.addColorStop(0,'#4FB2FF'); sky.addColorStop(0.55,'#8FD4FF'); sky.addColorStop(1,'#FFF3C4'); ctx.fillStyle=sky; ctx.fillRect(0,0,W,H);
      // sun
      ctx.fillStyle='#FFDE59'; ctx.beginPath(); ctx.arc(W-72,58,32,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='rgba(255,222,89,.35)'; ctx.beginPath(); ctx.arc(W-72,58,48,0,Math.PI*2); ctx.fill();
      // clouds
      g.clouds.forEach(c=>{ c.x-= (c.speed + (playing? g.speed*0.15:0.2))*fpsFactor; if(c.x<-120) {c.x=W+80; c.y=18+Math.random()*110;} ctx.fillStyle='rgba(255,255,255,.95)'; ctx.beginPath(); ctx.ellipse(c.x,c.y,34*c.s,18*c.s,0,0,Math.PI*2); ctx.ellipse(c.x-22*c.s,c.y+6*c.s,22*c.s,12*c.s,0,0,Math.PI*2); ctx.ellipse(c.x+24*c.s,c.y+6*c.s,24*c.s,13*c.s,0,0,Math.PI*2); ctx.fill(); });
      // hills
      ctx.fillStyle='#A8E063'; ctx.beginPath(); ctx.moveTo(0,groundY); ctx.quadraticCurveTo(W*0.25, groundY-110, W*0.5, groundY-30); ctx.quadraticCurveTo(W*0.75, groundY-120, W, groundY-40); ctx.lineTo(W,groundY); ctx.closePath(); ctx.fill();
      ctx.fillStyle='#8ED94F'; ctx.beginPath(); ctx.moveTo(0,groundY); ctx.quadraticCurveTo(W*0.3, groundY-60, W*0.6, groundY-10); ctx.quadraticCurveTo(W*0.85, groundY-70, W, groundY-20); ctx.lineTo(W,groundY); ctx.closePath(); ctx.fill();
      // trees parallax
      g.trees.forEach(t=>{ t.x-=(playing? g.speed*0.6:0.5)*fpsFactor; if(t.x<-80) t.x=W+80; const tx=t.x, ty=groundY-34*t.s; ctx.fillStyle='#6B3F1A'; ctx.fillRect(tx-4,ty,8,34*t.s); ctx.fillStyle='#2E9E4A'; ctx.beginPath(); ctx.arc(tx,ty-8,26*t.s,0,Math.PI*2); ctx.fill(); ctx.fillStyle='#3FC85A'; ctx.beginPath(); ctx.arc(tx-8,ty-16,16*t.s,0,Math.PI*2); ctx.fill(); });
      // ground
      ctx.fillStyle='#58B93A'; ctx.fillRect(0,groundY,W,H-groundY);
      ctx.fillStyle='#E8C88A'; ctx.fillRect(0,groundY+18,W,26);
      ctx.fillStyle='#C9A86A'; ctx.fillRect(0,groundY+44,W,4);
      // grass tufts (moving)
      ctx.strokeStyle='#3E8E2F'; ctx.lineWidth=2; for(let i=0;i<Math.ceil(W/36);i++){ const gx = (i*36 - (g.distance%36)); ctx.beginPath(); ctx.moveTo(gx,groundY+8); ctx.lineTo(gx+3,groundY); ctx.moveTo(gx+8,groundY+8); ctx.lineTo(gx+10,groundY+1); ctx.stroke(); }
      // coins
      g.coins.forEach(c=>{
        const bob=Math.sin(g.time*0.18 + c.phase)*3;
        ctx.save(); ctx.translate(c.x,c.y+bob);
        ctx.fillStyle='rgba(255,215,0,.35)'; ctx.beginPath(); ctx.arc(0,0,19,0,Math.PI*2); ctx.fill();
        ctx.fillStyle='#FFC93C'; ctx.beginPath(); ctx.arc(0,0,13,0,Math.PI*2); ctx.fill();
        ctx.strokeStyle='#E6A800'; ctx.lineWidth=2.5; ctx.stroke();
        ctx.fillStyle='#FFF3A8'; ctx.beginPath(); ctx.ellipse(-4,-5,4,6,-0.5,0,Math.PI*2); ctx.fill();
        ctx.fillStyle='#B8860B'; ctx.font='900 16px Baloo 2, sans-serif'; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText('$',0,1);
        // sparkle
        const sp=1+Math.sin(g.time*0.3+c.phase)*0.3; ctx.fillStyle='rgba(255,255,255,.9)'; ctx.beginPath(); ctx.arc(10*sp,-10,1.8,0,Math.PI*2); ctx.fill();
        ctx.restore();
      });
      // obstacles
      g.obstacles.forEach(o=>{
        if(o.kind==='fence'){ ctx.fillStyle='#8B5A2B'; ctx.fillRect(o.x, o.y+8, 6, o.h-8); ctx.fillRect(o.x+o.w-6, o.y+8, 6, o.h-8); ctx.fillStyle='#A67C4A'; ctx.fillRect(o.x, o.y, o.w, 7); ctx.fillRect(o.x, o.y+16, o.w, 7); ctx.fillStyle='#fff'; ctx.fillRect(o.x, o.y, o.w, 2); }
        else if(o.kind==='log'){ ctx.fillStyle='#7A4A21'; ctx.beginPath(); ctx.ellipse(o.x+o.w/2, o.y+o.h/2, o.w/2, o.h/2, 0,0,Math.PI*2); ctx.fill(); ctx.fillStyle='#D9A679'; ctx.beginPath(); ctx.ellipse(o.x+o.w-4, o.y+o.h/2, 7, o.h/2-3, 0,0,Math.PI*2); ctx.fill(); ctx.strokeStyle='#5A3415'; ctx.beginPath(); ctx.arc(o.x+o.w-4, o.y+o.h/2, 3,0,Math.PI*2); ctx.stroke(); }
        else { ctx.fillStyle='#9AA5B1'; ctx.beginPath(); ctx.moveTo(o.x, o.y+o.h); ctx.lineTo(o.x+8, o.y+4); ctx.lineTo(o.x+o.w-6, o.y); ctx.lineTo(o.x+o.w, o.y+o.h); ctx.closePath(); ctx.fill(); ctx.fillStyle='#CBD5E1'; ctx.beginPath(); ctx.moveTo(o.x+8, o.y+4); ctx.lineTo(o.x+18, o.y+12); ctx.lineTo(o.x+10, o.y+14); ctx.fill(); }
      });
      // horse shadow
      const shadowScale = 1 - Math.min(0.5, Math.abs(g.horseY)/220);
      ctx.fillStyle='rgba(0,0,0,.18)'; ctx.beginPath(); ctx.ellipse(g.horseX+16, groundY+8, 34*shadowScale, 6*shadowScale, 0,0,Math.PI*2); ctx.fill();
      // horse (blink on invuln)
      if(!(playing && g.invuln>0 && Math.floor(g.time/4)%2===0)){
        drawHorse(g.horseX+16, groundY+g.horseY-22, g.time, !g.grounded);
      }
      // particles
      g.particles.forEach(p=>{ ctx.globalAlpha=Math.max(0,p.life/p.max); ctx.fillStyle=p.color; ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill(); }); ctx.globalAlpha=1;
      // floaters
      g.floaters.forEach(f=>{ ctx.globalAlpha=Math.max(0,f.life/32); ctx.fillStyle='#FFF'; ctx.strokeStyle='#B8860B'; ctx.lineWidth=3; ctx.font='900 20px Baloo 2, sans-serif'; ctx.textAlign='center'; ctx.strokeText(f.text,f.x,f.y); ctx.fillText(f.text,f.x,f.y); }); ctx.globalAlpha=1;
      // speed lines when fast
      if(playing && g.speed>7){ ctx.strokeStyle='rgba(255,255,255,.55)'; ctx.lineWidth=2; for(let i=0;i<4;i++){ const yy=40+((i*67+g.time*2)%180); ctx.beginPath(); ctx.moveTo(W-20-((g.time*3+i*90)%160), yy); ctx.lineTo(W+20-((g.time*3+i*90)%160), yy); ctx.stroke(); } }
      ctx.restore();
      raf=requestAnimationFrame(frame);
    };
    raf=requestAnimationFrame(frame);
    return ()=>cancelAnimationFrame(raf);
  },[size]);

  // Keyboard
  useEffect(()=>{
    const onKey=(e:KeyboardEvent)=>{
      if(e.code==='Space'||e.code==='ArrowUp'||e.code==='KeyW'){ e.preventDefault(); if(screenRef.current==='start') startGame(); else if(screenRef.current==='gameover') startGame(); else doJump(); }
      if(e.code==='KeyP'){ if(screenRef.current==='playing'){ setScreenBoth('paused'); stopBg(); } else if(screenRef.current==='paused'){ setScreenBoth('playing'); startBg(); } }
      if(e.code==='KeyM'){ toggleSound(); }
      if(e.code==='KeyH'){ gHold(true); }
    };
    const onUp=(e:KeyboardEvent)=>{ if(e.code==='KeyH') gHold(false); };
    window.addEventListener('keydown',onKey); window.addEventListener('keyup',onUp);
    return ()=>{ window.removeEventListener('keydown',onKey); window.removeEventListener('keyup',onUp); };
  },[doJump]);

  const gHold=(v:boolean)=>{ game.current.holding=v; };
  const toggleSound=()=>{ const next=!soundRef.current; soundRef.current=next; setSoundOn(next); if(!next) stopBg(); else if(screenRef.current==='playing') startBg(); };

  const handlePressStart=()=>{ gHold(true); if(screenRef.current==='start') startGame(); else if(screenRef.current==='gameover') startGame(); else doJump(); };
  const handlePressEnd=()=>{ gHold(false); };

  const pauseGame=()=>{ if(screenRef.current==='playing'){ setScreenBoth('paused'); stopBg(); } };
  const resumeGame=()=>{ setScreenBoth('playing'); startBg(); };

  return (
    <div data-safe-area-inset-root style={{boxSizing:'border-box', paddingTop:'var(--safe-area-inset-top)', height:'100dvh', overflow:'hidden', background:'#4FB2FF', display:'flex', flexDirection:'column'}} className="no-select">
      {/* Top bar */}
      <div data-safe-area-sticky-top style={{top:'var(--safe-area-inset-top)'}} className="relative z-20 flex items-center justify-between gap-2 px-3 pt-2 pb-2 shrink-0">
        <div className="flex items-center gap-2 bg-white/95 rounded-full pl-2 pr-3 py-1 shadow-md border-2 border-[#2B1A0A]/10">
          <span className="w-8 h-8 rounded-full bg-[#FFD93D] flex items-center justify-center font-display font-extrabold text-[#2B1A0A] text-[15px]">🐴</span>
          <div className="leading-none"><div className="font-display font-extrabold text-[13px] tracking-wide">HORSE JUMP</div><div className="text-[10px] font-bold text-[#6B5A44]">COIN COLLECTOR • make.fun</div></div>
        </div>
        <div className="flex items-center gap-1.5">
          <button onClick={toggleSound} aria-label={soundOn?'Mute':'Unmute'} className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center active:scale-90 transition">{soundOn?<Volume2 size={19}/>:<VolumeX size={19}/>}</button>
          {(screen==='playing'||screen==='paused') && <button onClick={screen==='playing'?pauseGame:resumeGame} aria-label="Pause" className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center active:scale-90 transition">{screen==='playing'?<Pause size={19}/>:<Play size={19}/>}</button>}
        </div>
      </div>

      {/* HUD */}
      <div className="relative z-20 px-3 flex items-stretch gap-2 shrink-0">
        <div className="flex-1 bg-[#2B1A0A] text-white rounded-2xl px-3 py-2 shadow-lg flex items-center justify-between min-w-0">
          <div><div className="text-[10px] font-black tracking-widest text-[#FFD93D]">SCORE</div><div className="font-display font-extrabold text-[22px] leading-none tabular-nums">{hud.score}</div></div>
          <div className="text-right"><div className="text-[10px] font-black tracking-widest text-[#FFD93D] flex items-center gap-1 justify-end"><Coins size={11}/> COINS</div><div className="font-display font-extrabold text-[22px] leading-none tabular-nums">{hud.coins}</div></div>
        </div>
        <div className="bg-white rounded-2xl px-3 py-2 shadow-lg flex flex-col justify-center items-center min-w-[92px]">
          <div className="flex gap-0.5">{[0,1,2].map(i=><Heart key={i} size={18} className={i<hud.hearts?'fill-[#FF4757] text-[#FF4757]':'text-gray-300'} />)}</div>
          <div className="text-[10px] font-black tracking-widest text-[#6B5A44] mt-0.5 flex items-center gap-1"><Trophy size={11} className="text-[#E6A800]"/> BEST {Math.max(best, hud.score)}</div>
        </div>
      </div>

      {/* Game area */}
      <div ref={wrapRef} className="relative flex-1 mx-3 mt-2 mb-2 rounded-[28px] overflow-hidden border-[3px] border-white shadow-[0_18px_40px_rgba(0,0,0,.25)] bg-sky-300"
        onPointerDown={handlePressStart} onPointerUp={handlePressEnd} onPointerLeave={handlePressEnd} onPointerCancel={handlePressEnd}
        onContextMenu={e=>e.preventDefault()}>
        <canvas ref={canvasRef} style={{width:'100%', height:'100%', display:'block', touchAction:'none'}} />

        {/* Hint while playing */}
        {screen==='playing' && <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-black/35 text-white text-[11px] font-bold px-3 py-1 rounded-full pointer-events-none whitespace-nowrap">Tap = Jump • Double-tap = Double Jump • Hold = Higher</div>}

        {/* START */}
        {screen==='start' && (
          <div className="absolute inset-0 flex flex-col items-center justify-end pb-4 px-4 bg-gradient-to-t from-black/35 via-transparent to-transparent">
            <div className="w-full bg-white/95 rounded-[24px] p-4 shadow-2xl text-center animate-pop">
              <div className="inline-flex items-center gap-1 bg-[#FFF3C4] text-[#8A5A00] text-[11px] font-black px-3 py-1 rounded-full"><Sparkles size={12}/> SUNNY MEADOW • ENDLESS RUNNER</div>
              <h1 className="font-display font-extrabold text-[clamp(28px,7vw,38px)] leading-[0.95] mt-2">Horse Jump<br/><span className="text-[#FF8A00]">Coin Collector</span></h1>
              <p className="text-[13px] font-bold text-[#6B5A44] mt-1.5 leading-snug">Grab golden coins, leap fences, logs &amp; rocks.<br/>Tap to Jump — Double Tap for Double Jump.</p>
              <div className="flex justify-center gap-2 mt-3">
                <span className="bg-[#FFF7D6] rounded-full px-2.5 py-1 text-[11px] font-black">🪙 +10 / coin</span>
                <span className="bg-[#FFE8E8] rounded-full px-2.5 py-1 text-[11px] font-black">❤️ 3 hearts</span>
                <span className="bg-[#E8F7FF] rounded-full px-2.5 py-1 text-[11px] font-black">⚡ Gets faster</span>
              </div>
              <button onClick={(e)=>{e.stopPropagation(); startGame();}} className="mt-3 w-full bg-[#FFB800] hover:bg-[#FFC93C] border-b-[5px] border-[#D99A00] active:translate-y-0.5 active:border-b-2 rounded-2xl py-3.5 font-display font-extrabold text-[22px] flex items-center justify-center gap-2 shadow-lg"><Play className="fill-[#2B1A0A]"/> PLAY NOW</button>
              <p className="text-[11px] font-bold text-[#6B5A44] mt-2">Space / ↑ / W • P Pause • M Sound • Hold for higher jump</p>
            </div>
          </div>
        )}

        {/* PAUSED */}
        {screen==='paused' && (
          <div className="absolute inset-0 bg-black/45 flex items-center justify-center p-4" onPointerDown={e=>e.stopPropagation()}>
            <div className="bg-white rounded-[24px] p-5 w-full max-w-[320px] text-center animate-pop">
              <h2 className="font-display font-extrabold text-[28px]">Paused</h2>
              <p className="text-sm font-bold text-[#6B5A44]">Your horse is taking a breather.</p>
              <button onClick={resumeGame} className="mt-4 w-full bg-[#58B93A] border-b-[5px] border-[#2E7A1F] text-white rounded-2xl py-3 font-display font-extrabold text-lg flex items-center justify-center gap-2 active:translate-y-0.5"><Play size={20}/> RESUME</button>
              <button onClick={startGame} className="mt-2 w-full bg-white border-2 border-[#E5DCC8] rounded-2xl py-3 font-display font-extrabold text-lg flex items-center justify-center gap-2"><RotateCcw size={18}/> RESTART</button>
            </div>
          </div>
        )}

        {/* GAME OVER */}
        {screen==='gameover' && (
          <div className="absolute inset-0 bg-black/45 flex items-center justify-center p-4">
            <div className="bg-white rounded-[24px] p-5 w-full max-w-[340px] text-center animate-pop relative overflow-hidden">
              {isNewBest && <><div className="absolute inset-x-0 top-0 h-1 bg-[#FFD93D]"/><div className="pointer-events-none absolute inset-0">{[0,1,2,3,4,5,6,7].map(i=><span key={i} className="absolute w-2 h-3 rounded-sm" style={{left:`${8+i*12}%`, top:-8, background:['#FF4757','#FFD93D','#58B93A','#4FB2FF'][i%4], animation:`confettiFall ${1.2+i*0.15}s ease-in infinite`, animationDelay:`${i*0.12}s`}}/> )}</div></>}
              <div className="text-[11px] font-black tracking-[0.18em] text-[#6B5A44]">GAME OVER</div>
              {isNewBest ? <div className="mt-1 inline-flex items-center gap-1 bg-[#FFD93D] px-3 py-1 rounded-full font-display font-extrabold text-sm"><Trophy size={15}/> NEW BEST SCORE!</div> : <div className="mt-1 font-display font-extrabold text-[26px] leading-none">Nice Ride!</div>}
              <div className="grid grid-cols-3 gap-2 mt-4">
                <div className="bg-[#FFF7D6] rounded-2xl py-3"><div className="text-[10px] font-black text-[#8A5A00]">SCORE</div><div className="font-display font-extrabold text-[22px] leading-none">{hud.score}</div></div>
                <div className="bg-[#FFF7D6] rounded-2xl py-3"><div className="text-[10px] font-black text-[#8A5A00]">COINS</div><div className="font-display font-extrabold text-[22px] leading-none">{hud.coins}</div></div>
                <div className="bg-[#FFF7D6] rounded-2xl py-3"><div className="text-[10px] font-black text-[#8A5A00]">BEST</div><div className="font-display font-extrabold text-[22px] leading-none">{Math.max(best,hud.score)}</div></div>
              </div>
              <p className="text-[11px] font-bold text-[#6B5A44] mt-2 h-4">{saving?'Saving best score…':saveNote}</p>
              <button onClick={(e)=>{e.stopPropagation(); startGame();}} className="mt-1 w-full bg-[#FFB800] border-b-[5px] border-[#D99A00] rounded-2xl py-3.5 font-display font-extrabold text-[20px] flex items-center justify-center gap-2 active:translate-y-0.5"><RotateCcw/> PLAY AGAIN</button>
              <p className="text-[11px] font-bold text-[#6B5A44] mt-2">Tip: hold your tap a beat longer for a higher jump.</p>
            </div>
          </div>
        )}

        {/* Jump button */}
        {screen==='playing' && (
          <button aria-label="Jump" onPointerDown={(e)=>{e.stopPropagation(); gHold(true); doJump();}} onPointerUp={(e)=>{e.stopPropagation(); gHold(false);}} className="absolute bottom-4 right-4 w-[72px] h-[72px] rounded-full bg-[#FFB800] border-[3px] border-white shadow-[0_10px_20px_rgba(0,0,0,.3)] flex flex-col items-center justify-center active:scale-90 transition z-10">
            <ChevronUp size={28} strokeWidth={3}/><span className="font-display font-extrabold text-[12px] leading-none -mt-0.5">JUMP</span>
          </button>
        )}
      </div>

      {/* Bottom controls hint */}
      <div className="shrink-0 px-3 pb-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-white/95 bg-black/25 rounded-full px-3 py-1.5 text-[11px] font-bold"><Zap size={13} className="text-[#FFD93D]"/> Double-tap in the air for a second jump</div>
        <div className="text-white/90 text-[11px] font-bold bg-black/25 rounded-full px-3 py-1.5 whitespace-nowrap">Best: {Math.max(best,hud.score)} • {hud.coins} 🪙</div>
      </div>
    </div>
  );
}
